import java.io.*;
import java.util.*;
import java.math.*;


public class boas{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        BigInteger distance = new BigInteger("0");
        BigInteger prev;
        BigInteger x;

        prev = sc.nextBigInteger();

        while(--n != 0) {
            x = sc.nextBigInteger();
            BigInteger p = x.subtract(prev).multiply(x.subtract(prev));
            distance = distance.add(p);
            prev = x;
        }

        System.out.println(distance);
    }
}

