#include <cstdlib>
#include <iostream>
using namespace std;

// Problem solver for test session problem Frog Energy.
// Expected output: ACCEPTED

int main() {

    unsigned long long n;
    cin >> n;

    unsigned long long distance = 0;
    unsigned long long prev;
    unsigned long long x;

    cin >> prev;


    while(--n) {
        cin >> x;
        distance += (x - prev) * (x - prev);
        prev = x;
    }

    cout << distance << endl;
}
