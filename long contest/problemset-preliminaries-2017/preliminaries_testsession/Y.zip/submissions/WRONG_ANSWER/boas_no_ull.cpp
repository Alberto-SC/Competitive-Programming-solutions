#include <cstdlib>
#include <iostream>
using namespace std;

// Problem solver for test session problem Frog Energy.
// This solution doesn't store distance as an usigned long long
// Expected output: WRONG ANSWER

int main() {

    int n;
    cin >> n;

    int distance = 0;
    int prev;
    int x;

    cin >> prev;


    while(--n) {
        cin >> x;
        distance += (x - prev) * (x - prev);
        prev = x;
    }

    cout << distance << endl;
}
