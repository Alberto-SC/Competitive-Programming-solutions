import java.io.*;
import java.util.*;
import java.math.*;


public class boas_no_bigint{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        long distance = 0;
        int prev;
        int x;

        prev = sc.nextInt();

        while(--n != 0) {
            x = sc.nextInt();
            distance += (x - prev) * (x - prev);
            prev = x;
        }

        System.out.println(distance);
    }
}

