#include <iostream>
using namespace std;
int main() {
	int ans = 0;
	long long n, x, y;
	cin >> n >> x;
	while(cin >> y) ans += (y - x) * (y - x), x = y;
	return cout << ans << endl, 0;
}
