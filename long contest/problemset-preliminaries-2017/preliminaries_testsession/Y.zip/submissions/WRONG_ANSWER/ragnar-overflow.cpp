#include <iostream>
using namespace std;
int main() {
	long long ans = 0;
	int n, x, y;
	cin >> n >> x;
	while(cin >> y) ans += (y - x) * (y - x), x = y;
	return cout << ans << endl, 0;
}
