#include <bits/stdc++.h>
using namespace std;
int main() {
	int n, x, y, x2, y2;
	double a, b;
	cin >> n >> a >> b >> x >> y;
	vector<pair<int, int>> v(n);
	for(auto &p : v) cin >> p.first >> p.second;
	srand(31415);
	random_shuffle(v.begin(), v.end());
	cout << setprecision(10) << fixed;
	for(auto &p : v) {
		auto x2 = p.first, y2 = p.second;
		double d = hypot(x2 - x, y2 - y), angle = atan2(y2 - y, x2 - x);
		if(a <= d && d <= b) return cout << x2 << ' ' << y2 << ' ' << d << ' ' << angle << '\n', 0;
	}
	return cout << "impossible\n", 0;
}
