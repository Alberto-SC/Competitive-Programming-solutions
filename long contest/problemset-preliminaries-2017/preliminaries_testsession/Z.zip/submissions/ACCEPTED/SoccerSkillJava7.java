import java.util.Scanner;

public class SoccerSkillJava7 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int N     = s.nextInt();
		double a  = s.nextDouble();
		double b  = s.nextDouble();
		int x     = s.nextInt();
		int y     = s.nextInt();

		int[] teamx = new int[N];
		int[] teamy = new int[N];
		for(int i = 0; i < N; i++) {
			teamx[i] = s.nextInt();
			teamy[i] = s.nextInt();
		}

		for(int i = 0; i < N; i++) {
			int dist_sq = (teamx[i] - x) * (teamx[i] - x) + (teamy[i] - y) * (teamy[i] - y);
			if(a * a <= dist_sq && dist_sq <= b * b) {
				System.out.print(teamx[i]);
				System.out.print(' ');
				System.out.print(teamy[i]);
				System.out.print(' ');
				System.out.print(Math.sqrt(dist_sq));
				System.out.print(' ');
				System.out.print(Math.atan2(teamy[i] - y, teamx[i] - x));
				System.out.println();
				System.exit(0);
			}
		}

		System.out.println("impossible");
	}
}
