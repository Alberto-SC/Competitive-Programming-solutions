// Solution to: Soccer Skills
// By: Mees de Vries
//
// Expected answer: ACCEPTED

#include <algorithm>
#include <climits>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>

using namespace std;

int main() {
	int N, x, y;
	double a, b;
	cin >> N >> a >> b >> x >> y;
	vector<int> teamx(N), teamy(N);
	for(int i = 0; i < N; i++) cin >> teamx[i] >> teamy[i];

	for(int i = 0; i < N; i++) {
		int dist_sq = (teamx[i] - x) * (teamx[i] - x) + (teamy[i] - y) * (teamy[i] - y);
		if(a * a <= dist_sq && dist_sq <= b * b) {
			printf("%d %d %.8lf %.8lf\n", teamx[i], teamy[i], sqrt(dist_sq),
			       atan2(teamy[i] - y, teamx[i] - x));
			return 0;
		}
	}
	cout << "impossible" << endl;
	return 0;
}
