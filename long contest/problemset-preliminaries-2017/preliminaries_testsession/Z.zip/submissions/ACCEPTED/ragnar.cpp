#include <bits/stdc++.h>
using namespace std;
int main() {
	int n, x, y, x2, y2;
	double a, b;
	cin >> n >> a >> b >> x >> y;
	cout << setprecision(10) << fixed;
	while(cin >> x2 >> y2) {
		double d = hypot(x2 - x, y2 - y), angle = atan2(y2 - y, x2 - x);
		if(a <= d && d <= b) return cout << x2 << ' ' << y2 << ' ' << d << ' ' << angle << '\n', 0;
	}
	return cout << "impossible\n", 0;
}
