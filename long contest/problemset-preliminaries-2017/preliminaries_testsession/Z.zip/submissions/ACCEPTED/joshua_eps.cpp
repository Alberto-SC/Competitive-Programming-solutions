#include <bits/stdc++.h>
using namespace std;
using ld = long double;
ld atan3(ld dy, ld dx) {
	// we substract an allowed epsilon
	// this makes it wrap weirdly.
	ld ans = atan2(dy, dx) - 1e-7;
	if(ans < -M_PI) return ans + 2 * M_PI;
	return ans;
}

// Copied from Ragnar
int main() {
	int n, x, y, x2, y2;
	ld a, b;
	cin >> n >> a >> b >> x >> y;
	a *= a, b *= b;
	cout << setprecision(18) << fixed;
	while(cin >> x2 >> y2) {
		ld dx = x2 - x, dy = y2 - y, d = dx * dx + dy * dy;
		if(a <= d && d <= b)
			return cout << x2 << ' ' << y2 << ' ' << sqrt(d) << ' ' << atan3(dy, dx) << '\n', 0;
	}
	return cout << "impossible\n", 0;
}
