import java.io.*;
import java.util.*;

// Problem solver for test session problem CAPS.
// Expected output: TIME LIMIT EXCEEDED

public class boaz_tle {
	public String msg;
	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	public boaz_tle() {}

	public static void main(String[] args) throws Exception {
		new boaz_tle().solve();
	}

	public static void out(Object o, boolean newline) {
		if (newline) System.out.println(o.toString());
		else System.out.print(o.toString());
		System.out.flush();
	}

	public static void out(Object o) {
		out(o, true);
	}

	public void solve() throws Exception {
		while (true) {
			boolean stop = read_input();
			if (stop) return;
			magic();
		}
	}

	public void magic() throws Exception {
		String result = "";
		for (int i = 0; i < msg.length(); i++) {
			char c = Character.toUpperCase(msg.charAt(i));
			result = result.concat("" + c);
		}
		out(result);
	}

	public boolean read_input() throws Exception {
		msg = in.readLine();
		if (msg == null) return true;
		return false;
    }
}
