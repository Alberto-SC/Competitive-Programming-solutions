#include <iostream>
#include <string>
using namespace std;
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	string s;
	cin >> s;
	for(auto &x : s) x += 'A' - 'a';
	cout << s << endl;
}
