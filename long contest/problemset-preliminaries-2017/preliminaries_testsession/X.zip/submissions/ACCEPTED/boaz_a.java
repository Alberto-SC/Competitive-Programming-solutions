import java.io.*;
import java.util.*;

// Problem solver for test session problem CAPS.
// Expected output: ACCEPTED

public class boaz_a {
	public String msg;
	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	public boaz_a() {}

	public static void main(String[] args) throws Exception {
		new boaz_a().solve();
	}

	public static void out(Object o, boolean newline) {
		if (newline) System.out.println(o.toString());
		else System.out.print(o.toString());
		System.out.flush();
	}

	public static void out(Object o) {
		out(o, true);
	}

	public void solve() throws Exception {
		while (true) {
			boolean stop = read_input();
			if (stop) return;
			magic();
		}
	}

	public void magic() throws Exception {
        out(msg.toUpperCase());
	}

	public boolean read_input() throws Exception {
		msg = in.readLine();
		if (msg == null) return true;
		return false;
    }
}
