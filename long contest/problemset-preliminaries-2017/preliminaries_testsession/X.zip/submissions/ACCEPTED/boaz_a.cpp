#include <iomanip>
#include <iostream>
#include <string>
#include <algorithm>

// Problem solver for test session problem CAPS.
// Expected output: ACCEPTED

int main() {
	std::string msg;
	std::cin >> msg;

	transform(msg.begin(), msg.end(), msg.begin(), ::toupper);

	std::cout << msg << "\n";
}
