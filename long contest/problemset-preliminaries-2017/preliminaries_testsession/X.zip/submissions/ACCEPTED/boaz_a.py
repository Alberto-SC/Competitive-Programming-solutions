"""
Problem solver for test session problem CAPS.
Expected output: ACCEPTED
"""

import sys
from collections import deque
instr = sys.stdin

MIN_L = 1
MAX_L = 10**6

def magic(text, verbose = False):
	print(text.upper())

def read_input():
	input = instr.readline()[0:-1]
        # input checking is done elsewhere!
	#if not input: return None
	#assert(len(input) >= MIN_L and len(input) <= MAX_L) # Input checking
	#assert(input.isalpha() or input=='\n') # Input checking

	return input

def solve():
	text = read_input()
	magic(text)

def main():
	solve()

if __name__ == "__main__":
	main()
