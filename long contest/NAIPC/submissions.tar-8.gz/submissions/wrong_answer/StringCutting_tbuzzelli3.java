import java.util.*;

public class StringCutting_tbuzzelli3 {
    static int oo = 1000000000;
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        while(t-->0) {
            int k = in.nextInt();
            char[] str = in.next().toCharArray();
            int n = str.length;
            int[] suf = suffixArray(str);
            int[] rev = new int[n];
            for (int i = 0; i < n; i++) rev[suf[i]] = i;
            int[][] nexts = new int[n + 1][26];
            Arrays.fill(nexts[n], oo);
            for (int i = n - 1; i >= 0; i--) {
                for (int j = 0; j < 26; j++)
                    nexts[i][j] = nexts[i + 1][j];
                nexts[i][str[i] - 'a'] = i;
            }
            StringBuilder sb = new StringBuilder();
            int idx = 0;
            for (int ch = 25; ch >= 0 && idx < n && k > 0; ch--) {
                char let = (char) (ch + 'a');
                while (idx < n && str[idx] == let)
                    sb.append(str[idx++]);
                ArrayList<Integer> list = new ArrayList<>();
                for (int i = idx + 1; i < n && nexts[i][ch] < oo; i++) {
                    if (str[i] == let && str[i - 1] != let)
                        list.add(i);
                }
                Collections.sort(list, (a, b) -> rev[b] - rev[a]);
                for (int i = 0; i < list.size() && k-- > 0; i++) {
                    int j = list.get(i);
                    while (j < n && str[j] == let)
                        sb.append(str[j++]);
                    idx = Math.max(idx, j);
                }
            }
            for (int i = idx; i < n; i++)
                sb.append(str[i]);
            System.out.println(sb);
        }
    }
    
    static int[] suffixArray(char[] str) {
        int n = str.length;
        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++) order[i] = n - i - 1;
        Arrays.sort(order, (a, b) -> Character.compare(str[a], str[b]));
        int[] sa = new int[n];
        int[] classes = new int[n];
        for (int i = 0; i < n; i++) {
            sa[i] = order[i];
            classes[i] = str[i];
        }
        for (int len = 1; len < n; len *= 2) {
            int[] c = classes.clone();
            for (int i = 0; i < n; i++)
                classes[sa[i]] = i > 0 && c[sa[i - 1]] == c[sa[i]] && sa[i - 1] + len < n && c[sa[i - 1] + len / 2] == c[sa[i] + len / 2] ? classes[sa[i - 1]] : i;
            int[] cnt = new int[n];
            for (int i = 0; i < n; i++) cnt[i] = i;
            int[] s = sa.clone();
            for (int i = 0; i < n; i++) {
                int s1 = s[i] - len;
                if (s1 >= 0) sa[cnt[classes[s1]]++] = s1;
            }
        }
        return sa;
    }
}
