#include <bits/stdc++.h>

using namespace std;

struct suffix {
    int rank[2];
    int index;
};

bool cmp(suffix a, suffix b) {
    return a.rank[0] == b.rank[0] ? a.rank[1] < b.rank[1] : a.rank[0] < b.rank[0];
}

struct sarray {
    vector<int> idx, sarr, lcp;
    vector<suffix> suf;
    string t;
    int n;

    sarray(int sz) : idx(sz), suf(sz), sarr(sz), lcp(sz) {}

    void build(string &s) {
        t = s;
        n = s.size();
        for (int i = 0; i < n; ++i) {
            suf[i].index = i;
            suf[i].rank[0] = s[i] - ' ';
            suf[i].rank[1] = (i+1) < n ? s[i+1] - ' ' : -1;
        }
        sort(suf.begin(), suf.begin() + n, cmp);
        for (int len = 4; len < 2*n; len *= 2) {
            int rank = 0, prev_rank = suf[0].rank[0];
            suf[0].rank[0] = rank;
            idx[suf[0].index] = 0;

            for (int i = 1; i < n; ++i) {
                if (suf[i].rank[0] == prev_rank && suf[i].rank[1] == suf[i-1].rank[1]) {
                    suf[i].rank[0] = rank;
                } else {
                    prev_rank = suf[i].rank[0];
                    suf[i].rank[0] = ++rank;
                }
                idx[suf[i].index] = i;
            }

            for (int i = 0; i < n; ++i) {
                int next = suf[i].index + len/2;
                suf[i].rank[1] = next < n ? suf[idx[next]].rank[0] : -1;
            }
            sort(suf.begin(), suf.begin()+n, cmp);
        }

        for (int i = 0; i < n; ++i) {
            sarr[i] = suf[i].index;
        }
    }

    int& operator[](int pos) {
        return sarr[pos];
    }
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t; cin >> t;
    while (t--) {
        int k; cin >> k;
        string s; cin >> s;
        map<char, set<int>> pos;
        int n = s.size();
        for (int i = 0; i < n; ++i) {
            pos[s[i]].insert(i);
        }

        string ans;
        char c;
        for (auto it = pos.rbegin(); it != pos.rend(); ++it) {
            set<int> loc;
            tie(c, loc) = *it;
            int last = -1 + (n-s.size());
            int req = 0;
            for (int i : loc) {
                if (i <= last) {
                    loc.erase(i);
                    continue;
                }
                if (i != last+1) ++req;
                last = i;
            }
            if (k != 0 && k >= req) {
                for (int i = 0; i < loc.size(); ++i) ans.push_back(c);
                k -= req;
                if (req != 0) s = s.substr(last-(n-s.size())+1);
            } else {
                int i;
                for (i = 0; i < s.size() && s[i] == c; ++i) {
                    ans.push_back(c);
                }
                s = s.substr(i);
                break;
            }
        }
        if (k > 0 && s.size() > 0) {
            sarray suf(s.size());
            suf.build(s);
            vector<int> inv(s.size());
            for (int i = 0; i < s.size(); ++i) {
                inv[suf[i]] = i;
            }
            vector<pair<int, int>> clump;
            int len = 0;
            for (int i = 0; i < s.size(); ++i) {
                if (s[i] == c) {
                    ++len;
                } else if (len > 0) {
                    clump.push_back({i-len, len});
                    len = 0;
                }
            }
            if (len > 0) {
                clump.push_back({s.size()-len, len});
            }

            multiset<int> lens;
            for (auto &p : clump) {
                lens.insert(p.second);
            }
            int count = 0;
            int target = 0;
            for (auto it = lens.rbegin(); it != lens.rend(); ++it) {
                target += *it;
                ++count;
                if (count == k) break;
            }
            lens.clear();
            int sum = 0;
            int ind = -1, ord = -1;
            for (auto &p : clump) {
                lens.insert(p.second);
                sum += p.second;
                if (lens.size() > k) {
                    sum -= *lens.begin();
                    lens.erase(lens.begin());
                }
                if (sum == target && lens.count(p.second)) {
                    int cpos = p.first + p.second;
                    int val = cpos < s.size() ? inv[cpos] : 0;
                    if (val > ord) {
                        ord = inv[cpos];
                        ind = cpos;
                    }
                }
            }

            for (int i = 0; i < target; ++i) ans.push_back(c);
            s = s.substr(ind);
        }
        ans += s;
        cout << ans << endl;
    }
}
