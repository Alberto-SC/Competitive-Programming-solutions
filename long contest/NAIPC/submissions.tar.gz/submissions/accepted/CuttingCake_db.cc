// Problem         : Piece of Cake (NAIPC 2019)
// Author          : Darcy Best
// Expected Result : AC
// Complexity      : O(n^2)
 
// Compute the probability of a (directed) edge being on the
// outside of the convex polygon and add the signed area below it.
// (Using shoelace formula)
// Compute the probabilities in a sweeping fashion.

#include <iostream>
#include <utility>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;

double area(const pair<double,double>& p,const pair<double,double>& q){
  return p.first * q.second - p.second * q.first;
}

int main(){
  int n, k; cin >> n >> k;

  vector<pair<double,double> > A(n);
  for(auto& x : A)
    cin >> x.first >> x.second;

  reverse(begin(A), end(A)); // I want counter-clockwise

  double ans = 0;
  for(int i=0;i<n;i++){
    // (n-2 choose k-2) / (n choose k)
    double prob = (k * (k-1)) / 1.0 / (n * (n-1));

    int left = n-2;
    for(int dist=1;left >= k-2;dist++,left--){
      ans += prob * area(A[i],A[(i+dist)%n]);
      prob *= (left-(k-2)) / 1.0 / left;
    }
  }

  cout << fixed << setprecision(10) << ans/2 << endl;
}
