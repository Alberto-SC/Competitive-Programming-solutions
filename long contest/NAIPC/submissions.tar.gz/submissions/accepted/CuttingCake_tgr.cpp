#include <iostream>
#include <vector>
#include <iomanip>
using namespace std ;
typedef pair<double, double> pt ;
typedef long long ll ;
int N, K ;
vector<pt> cake ;
double cnt ;
double sum ;
double choose(double a, double b) {
   if (b < 0 || b > a)
      return 0 ;
   if (b + b > a)
      b = a - b ;
   double r = 1 ;
   for (double i=1; i<=b; i++)
      r = r * (a - i + 1) / i ;
   return r ;
}
double incr(int i, int j) {
   return (cake[i].second + cake[j].second) * (cake[j].first - cake[i].first) * 0.5 ;
}
int main() {
   cin >> N >> K ;
   cake = vector<pt>(N) ;
   for (int i=0; i<N; i++)
      cin >> cake[i].first >> cake[i].second ;
   for (int i=0; i<N; i++) {
      double p = K * (K - 1) / (double)(N * (N - 1)) ;
      for (int m=1; m<N; m++) {
         sum += p * incr(i, (i + m) % N) ;
         p *= (1 - (K - 2) / (double)(N - m - 1)) ;
      }
   }
   cout << setprecision(15) << sum << endl ;
}
