import java.util.*;
import java.io.*;

public class CuttingCake_tbuzzelli {
    
    static double[] xs, ys;
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        xs = new double[n * 2];
        ys = new double[n * 2];
        for (int i = n - 1; i >= 0; i--) {
            xs[i] = xs[i + n] = in.nextDouble();
            ys[i] = ys[i + n] = in.nextDouble();
        }
        double[] sums = new double[n + 1];
        double totalArea = 0;
        for (int i = 0; i < n; i++) {
            totalArea += cross(i, i + 1);
        }
        totalArea = Math.abs(totalArea);
        for (int i = 0; i < n; i++) {
            double area = 0;
            for (int j = i + 1; j < i + n; j++) {
                area += cross(j - 1, j);
                sums[j - i + 1] += Math.abs(area + cross(j, i));
            }
        }
        double ans = totalArea;
        double totalWays = nckLog(n, k);
        for (int i = 0; i <= n; i++) {
            if (k - 2 > n - i || sums[i] == 0) continue;
            double ways = nckLog(n - i, k - 2);
            ans -= Math.exp(Math.log(sums[i]) + ways - totalWays);
        }
        System.out.printf("%.8f\n", ans / 2);
    }
    
    static double cross(int i, int j) {
        return xs[i] * ys[j] - ys[i] * xs[j];
    }

    static double nckLog(int n, int k) {
        double prev = 0;
        for (long c = 1; c <= k; c++) {
            prev += Math.log(n - c + 1) - Math.log(c);
        }
        return prev;
    }
}
