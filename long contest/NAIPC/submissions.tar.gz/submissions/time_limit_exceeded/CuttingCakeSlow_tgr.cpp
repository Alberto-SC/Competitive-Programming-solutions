#include <iostream>
#include <iomanip>
#include <vector>
using namespace std ;
typedef pair<double, double> pt ;
typedef long long ll ;
int N, K ;
vector<pt> cake ;
ll cnt ;
double sum ;
double incr(int i, int j) {
   return (cake[i].second + cake[j].second) * (cake[j].first - cake[i].first) * 0.5 ;
}
void recur(int prev, int first, int at, int pts, double area) {
   if (pts > K || N - at < K - pts)
      return ;
   if (at == N) {
      if (pts == K) {
         cnt++ ;
         area += incr(prev, first) ;
         sum += area ;
      }
      return ;
   }
   recur(prev, first, at+1, pts, area) ;
   if (first < 0)
      recur(at, at, at+1, pts+1, area) ;
   else
      recur(at, first, at+1, pts+1, area+incr(prev, at)) ;
}
int main() {
   cin >> N >> K ;
   cake = vector<pt>(N) ;
   for (int i=0; i<N; i++)
      cin >> cake[i].first >> cake[i].second ;
   recur(-1, -1, 0, 0, 0) ;
   double avg = sum / cnt ;
   cout << setprecision(15) << avg << endl ;
}
