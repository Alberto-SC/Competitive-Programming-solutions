#include <iostream>
typedef long long ll ;
using namespace std ;
int main() {
  int C;
  cin >> C;

  for(int c=0;c<C;c++){
   ll p, q, n ;
   cin >> p >> q >> n ;
   ll r = 0 ;
   for (ll i=1; i<=n; i++)
      r += p * i % q ;
   cout << r << endl ;
  }
}
