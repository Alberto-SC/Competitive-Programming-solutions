// Problem         : Mod Mod Mod (NAIPC 2019)
// Author          : Darcy Best
// Expected Result : TLE
// Complexity      : O(n) per test case
 
// Just naively compute the answer

#include <iostream>
using namespace std;

void add(long long& x, long long p, long long q){
  x += p;
  if(x >= q) x -= q;
}

int main(){
  ios_base::sync_with_stdio(false); cin.tie(0);

  int C; cin >> C;

  while(C--){
    long long p,q,n; cin >> p >> q >> n;
    p %= q;

    long long curr = p;

    long long ans = 0;
    for(int i=0;i<n;i++){
      ans += curr;
      add(curr,p,q);
    }

    cout << ans << "\n";
  }
}
