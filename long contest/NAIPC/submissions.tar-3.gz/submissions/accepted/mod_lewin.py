t = int(raw_input())

def gcd(a,b):
	return b if a == 0 else gcd(b % a, a)

def solveInner(p,q,n):
	if p == 0:
		return 0
	if p >= q:
		return n*(n+1)/2*(p/q) + solveInner(p%q, q, n)
	M = (n*p)/q
	return n*M + M/p - solveInner(q,p,M)

def solve(p,q,n):
	g = gcd(p,q)
	return p * n * (n+1)/2 - q * solveInner(p/g, q/g, n)

for ___ in xrange(t):
	p,q,n = map(int, raw_input().split())
	print solve(p,q,n)
