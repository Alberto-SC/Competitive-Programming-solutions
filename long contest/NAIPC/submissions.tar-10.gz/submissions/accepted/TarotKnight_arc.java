import java.util.*;

/*
 * Problem: Tarot Knight (NAIPC19)
 * Author: Alex Coleman
 * Complexity: O(n*k*lg)
 *   where k = number of unique gcd's reachable from subsets of
 *   n numbers up to a or b (10^9), k ~ 30,000
 *   lg = log(10^9), but is from gcd function so very low overhead
 * 
 * We can always compress a single card (a,b) to (g,0) or (g,g) where g = gcd(a,b)
 * If a/g and b/g are = mod 2, then we can show it's equal to (g,0), otherwise it is (g,g)
 * Additionally, the reachability of (g,0) and (g,g) is easy to check (see card.canDo)
 * 
 * Next, we can show that merging cards with value x and y similarly reduces to a single card
 * of type (g,0) or (g,g) where g=gcd(x,y) (see merge function for details)
 * 
 * With this in mind, we can do a DP where state is the card we have, and transition is trying every card to merge with.
 * We can always assume we return to start after buying a card (since travel is not a cost).
 */
public class TarotKnight_arc {
	static final long oo = Long.MAX_VALUE/3;
	static HashMap<Integer,Long> memo;
	static int n,sx,sy;
	static Card[] cs;
	static int[] xs,ys;
	static long[] costs;
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		n = in.nextInt();
		xs = new int[n];
		ys = new int[n];
		costs = new long[n];
		cs = new Card[n];
		for(int i=0;i<n;i++) {
			xs[i] = in.nextInt();
			ys[i] = in.nextInt();
			cs[i] = new Card(in.nextInt(), in.nextInt());
			costs[i] = in.nextLong();
		}
		sx = xs[0];
		sy = ys[0];
		long ans = oo;
		if(sx == 0 && sy == 0) {
			ans = 0;
		} else {
			memo = new HashMap<>();
			for(int i=0;i<n;i++) {
				if(xs[i] == sx && ys[i] == sy)
					ans = Math.min(ans, solve(cs[i]) + costs[i]);
			}
		}
		System.out.println(ans == oo ? -1 : ans);
	}
	static long solve(Card c) {
		if(c.canDo(-sx, -sy))
			return 0;
		
		int id = c.id();
		Long res = memo.get(id);
		if(res != null)
			return res;
		
		long ans = oo;
		for(int i=0;i<n;i++) {
			if(!c.canDo(xs[i]-sx, ys[i]-sy))
				continue;
			Card nc = c.merge(cs[i]);
			if(nc.id() != c.id()) {
				ans = Math.min(ans, solve(nc) + costs[i]);
			}
		}
		memo.put(id, ans);
		return ans;
	}
	
	static int gcd(int a, int b) {
		return b == 0 ? a : gcd(b,a%b);
	}
	
	static class Card {
		int x;
		boolean orth;
		public Card(int a, int b) {
			x = gcd(a,b);
			orth = (a/x%2 == 0) != (b/x%2 == 0);
		}
		public Card(int x, boolean orth) {
			this.x = x;
			this.orth = orth;
		}
		Card merge(Card c) {
			if(c == null)
				return this;
			int g = gcd(x, c.x);
			if(orth == c.orth) {
				return new Card(g, orth);
			}
			Card orthCard = orth ? this : c;
			boolean nOrth = orthCard.x / g % 2 != 0;
			return new Card(g,nOrth);
		}
		boolean canDo(int dx, int dy) {
			if(dx % x != 0 || dy % x != 0)
				return false;
			return orth || (dx/x+dy/x)%2==0;
		}
		int id() {
			return x*2+(orth?1:0);
		}
	}
}
