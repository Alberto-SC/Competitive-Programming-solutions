/* 
 * O(n^2)
 * @author godmar
 */
#include <iostream>
#include <vector>
using namespace std;

typedef long long ll;
struct Rectangle {
    ll x1, x2, y1, y2;
    // for rectangles to intersect, one point must lie inside
    // the other and at least one point must lie outside the other.
    bool intersects(Rectangle & that) {
        return (*this).haspointinside(that) && (*this).haspointoutside(that)
            || that.haspointinside(*this) && that.haspointoutside(*this);
    }
    bool haspointinside(Rectangle &that) {
        return inside(that.x1, that.y1) ||
               inside(that.x1, that.y2) ||
               inside(that.x2, that.y1) ||
               inside(that.x2, that.y2);
    }
    bool haspointoutside(Rectangle &that) {
        return !inside(that.x1, that.y1) ||
               !inside(that.x1, that.y2) ||
               !inside(that.x2, that.y1) ||
               !inside(that.x2, that.y2);
    }
    bool inside(int x, int y) {
        return x1 <= x && x <= x2 && y1 <= y && y <= y2;
    }
};

int
main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    vector<Rectangle> rect;

    for (int i = 0; i < n; i++) {
        ll x1, x2, y1, y2;
        cin >> x1 >> y1 >> x2 >> y2;
        rect.emplace_back(Rectangle { x1, x2, y1, y2 });
    }

    for (int i = 0; i < n; i++) {
        for (int j = i+1; j < n; j++) {
            if (rect[i].intersects(rect[j])) {
                cout << 1 << endl;
                return 0;
            }
        }
    }
    cout << 0 << endl;
    return 0;
}
