/**
 * Attempt at NAIPC 2019 Rectangles, CodeForces style
 *
 * @author godmar@gmail.com
 */
#include <vector>
#include <tuple>
#include <functional>
#include <cstdio>
#include <map>
#include <algorithm>
using namespace std;

typedef long long ll;
struct Rectangle { ll x1, x2, y1, y2; };

int
main()
{
    int n;
    vector<Rectangle> rect;
    if (scanf("%d\n", &n) != 1) abort();
    for (int i = 0; i < n; i++) {
        ll x1, x2, y1, y2;
        if (scanf("%lld %lld %lld %lld\n", &x1, &y1, &x2, &y2) != 4) abort();
        rect.emplace_back(Rectangle { x1, x2, y1, y2 });
    }

    vector<tuple<ll, int, int>> events;
    map<int, int> iv;

    for (int i = 0; i < n; i++) {
        events.emplace_back(rect[i].x1, 0, i);
        events.emplace_back(rect[i].x2, 1, i);
    }
    sort(events.begin(), events.end());

    for (auto & e : events) {
        auto & type = get<1>(e);
        auto & r = rect[get<2>(e)];
        if (type == 0) {
            auto e = iv.lower_bound(r.y1);
            if (e != iv.end()) {
                auto yj = e->second;
                if (r.y1 < yj && yj < r.y2)
                    return printf("1\n"), 0; 
            }
            e = iv.upper_bound(r.y1);
            if (e != iv.end()) {
                auto yi = e->first;
                auto yj = e->second;
                if (r.y1 < yi && yj < r.y2 || r.y1 < yi && yi < r.y2)
                    return printf("1\n"), 0; 
            }
            iv[r.y1] = r.y2;
        } else {
            iv.erase(r.y1);
            auto e = iv.upper_bound(r.y1);
            if (e != iv.end()) {
                auto yi = e->first;
                auto yj = e->second;
                if (r.y1 < yi && yj < r.y2 || yi < r.y2 && r.y2 < yj)
                    return printf("1\n"), 0; 
            }
        }
    }

    printf("0\n");
    return 0;
}
