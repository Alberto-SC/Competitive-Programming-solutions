/* 
 * Try to "cheese" the problem by cross-checking the first & last 1000,
 * as well as 1000 in the middle, then spending the rest of the allowable 
 * CPU time randomly checking pairs.
 *
 * @author godmar
 */
#define TRY_FOR_THIS_MANY_CPU_SECONDS 2.5

#include <iostream>
#include <vector>
#include <chrono>
#include <ctime>
using namespace std;

typedef long long ll;
struct Rectangle {
    ll x1, x2, y1, y2;
    // for rectangles to intersect, one point must lie inside
    // the other and at least one point must lie outside the other.
    bool intersects(Rectangle & that) {
        return (*this).haspointinside(that) && (*this).haspointoutside(that)
            || that.haspointinside(*this) && that.haspointoutside(*this);
    }
    bool haspointinside(Rectangle &that) {
        return inside(that.x1, that.y1) ||
               inside(that.x1, that.y2) ||
               inside(that.x2, that.y1) ||
               inside(that.x2, that.y2);
    }
    bool haspointoutside(Rectangle &that) {
        return !inside(that.x1, that.y1) ||
               !inside(that.x1, that.y2) ||
               !inside(that.x2, that.y1) ||
               !inside(that.x2, that.y2);
    }
    bool inside(int x, int y) {
        return x1 <= x && x <= x2 && y1 <= y && y <= y2;
    }
};

int
main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    vector<Rectangle> rect;

    for (int i = 0; i < n; i++) {
        ll x1, x2, y1, y2;
        cin >> x1 >> y1 >> x2 >> y2;
        rect.emplace_back(Rectangle { x1, x2, y1, y2 });
    }

    #define CHEESE 1000
    for (int i = 0; i < min(CHEESE, n); i++) {
        for (int j = 0; j < min(CHEESE, n); j++) {
            if (i != j && rect[i].intersects(rect[j])) {
                cout << 1 << endl;
                return 0;
            }
        }
        for (int j = max(0, n-CHEESE); j < n; j++) {
            if (i != j && rect[i].intersects(rect[j])) {
                cout << 1 << endl;
                return 0;
            }
        }
    }

    for (int i = max(0, n-CHEESE); i < n; i++) {
        for (int j = 0; j < min(CHEESE, n); j++) {
            if (i != j && rect[i].intersects(rect[j])) {
                cout << 1 << endl;
                return 0;
            }
        }
        for (int j = max(0, n-CHEESE); j < n; j++) {
            if (i != j && rect[i].intersects(rect[j])) {
                cout << 1 << endl;
                return 0;
            }
        }
    }

    for (int i = max(0, n/2-CHEESE/2); i < min(n/2+CHEESE/2, n); i++) {
        for (int j = max(0, n/2-CHEESE/2); j < min(n/2+CHEESE/2, n); j++) {
            if (i != j && rect[i].intersects(rect[j])) {
                cout << 1 << endl;
                return 0;
            }
        }
    }

    clock_t c_start = clock();
    srand(c_start);
    while ((double) (clock() - c_start) / CLOCKS_PER_SEC < TRY_FOR_THIS_MANY_CPU_SECONDS) {
        int i = rand() % n;
        int j = rand() % n;
        if (i != j && rect[i].intersects(rect[j])) {
            cout << 1 << endl;
            return 0;
        }
    }

    cout << 0 << endl;
    return 0;
}
