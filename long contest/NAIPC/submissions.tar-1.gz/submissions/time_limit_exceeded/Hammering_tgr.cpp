#include <iostream>
#include <vector>
#include <set>
#include <string>
using namespace std ;
int w, h, a ;
typedef long long ll ;
typedef unsigned long long ull ;
vector<ull> moves ;
vector<ull> q ;
set<ull> seen ;
int main() {
   cin >> w >> h ;
   int a = w * h ;
   if (a > 64) {
      // dummy loop to make it TLE even when we can't handle the input
      while (a > 60)
         a |= 1 ;
      cout << "Limits too large for this program." << endl ;
   }
   for (int m=0; m<a; m++) {
      ull mv = 0 ;
      for (int b=0; b<a; b++)
         if (b / w == m / w || b % w == m % w)
            mv |= 1LL << b ;
      moves.push_back(mv) ;
   }
   vector<ull> ends ;
   string row ;
   for (int i=0; i<2; i++) {
      ull v = 0 ;
      for (int y=0; y<h; y++) {
         cin >> row ;
         for (int x=0; x<w; x++)
            if (row[x] == 'O')
               v |= (1LL << (x + h * y)) ;
      }
      ends.push_back(v) ;
   }
   ull start = ends[0] ;
   ull target = ends[1] ;
   if (start == target) {
      cout << 1 << endl ;
      exit(0) ;
   }
   q.push_back(start) ;
   seen.insert(start) ;
   ll qg = 0 ;
   while (qg < q.size()) {
      ull v = q[qg++] ;
      for (int m=0; m<a; m++) {
         if (((v >> m) & 1) == 0)
            continue ;
         ull t = (moves[m] | v) & ~(1LL << m) ;
         if (seen.find(t) == seen.end()) {
            seen.insert(t) ;
            q.push_back(t) ;
            if (t == target) {
               cout << 1 << endl ;
               exit(0) ;
            }
         }
      }
   }
   cout << 0 << endl ;
}
