#include <bits/stdc++.h>

using namespace std;

struct edge {
    int u, v, cap;
};

typedef vector<vector<int>> graph;

#define INF numeric_limits<int>::max()

bool bfs(graph &g, vector<edge> &e, vector<int> &level, int s, int t) {
	for (int i = 0; i < g.size(); ++i) {
		level[i] = -1;
	}
	level[s] = 0;

	queue<int> q; q.push(s);

	while (!q.empty()) {
		int u = q.front(); q.pop();
		for (int i : g[u]) {
			int v = e[i].v, w = e[i].cap;
			if (level[v] < 0 && w > 0) {
				level[v] = level[u] + 1;
				q.push(v);
			}
		}
	}

	return level[t] >= 0;
}

int dfs(graph &g, vector<edge> &e, vector<int> &level, vector<int> &start, int u, int t, int flow) {
	if (u == t) return flow;

	for (int &i = start[u]; i < g[u].size(); ++i) {
		int v = e[g[u][i]].v, w = e[g[u][i]].cap;
		if (level[v] == level[u]+1 && w > 0) {
			int cur_flow = min(flow, w);
			int temp_flow = dfs(g, e, level, start, v, t, cur_flow);
			if (temp_flow > 0) {
				e[g[u][i]].cap -= temp_flow;
				e[g[u][i]^1].cap += temp_flow;
				return temp_flow;
			}
		}
	}

	return 0;
}

int dinic(graph &g, vector<edge> &e, int s, int t) {
	int total = 0;
	vector<int> level(g.size());
	vector<int> start(g.size());

	while (bfs(g, e, level, s, t)) {
        fill(start.begin(), start.end(), 0);
		while (int flow = dfs(g, e, level, start, s, t, INF)) {
			total += flow;
		}
	}

	return total;
}

void bfs2(graph &g, vector<edge> &e, vector<bool> &vis, int src, bool forward) {
    queue<int> q; q.push(src);
    while (!q.empty()) {
        int cur = q.front(); q.pop();
        if (vis[cur]) continue;
        vis[cur] = true;
        for (int i : g[cur]) {
            if ((e[i].cap > 0) == forward) {
                q.push(e[i].v);
            }
        }
    }
}

void add_edge(graph &g, vector<edge> &e, int u, int v, int cap) {
    g[u].push_back(e.size());
    e.push_back({u, v, cap});
    g[v].push_back(e.size());
    e.push_back({v, u, 0});
}

int main() {
    int n, m; cin >> n >> m;
    graph g(2*n+2);
    vector<edge> e;
    int src = 2*n, snk = src+1;
    for (int i = 0; i < n; ++i) {
        add_edge(g, e, src, i, 1);
        add_edge(g, e, n+i, snk, 1);
    }

    for (int i = 0; i < m; ++i) {
        int a, b; cin >> a >> b;
        --a; --b;
        add_edge(g, e, a, n+b, 1);
    }
    int flights = (n-1) - dinic(g, e, src, snk);
    cout << flights << endl;
    if (flights > 0) {
        vector<bool> start(g.size()), end(g.size());
        bfs2(g, e, end, src, true);
        bfs2(g, e, start, snk, false);
        set<int> air;
        for (int i = 0; i < n; ++i) {
            if (end[i] || start[n+i]) air.insert(i+1);
        }
        for (int i : air) cout << i << " ";
        cout << endl;
    }
}
