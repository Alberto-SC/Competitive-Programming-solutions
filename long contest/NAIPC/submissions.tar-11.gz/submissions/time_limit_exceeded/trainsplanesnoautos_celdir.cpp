#include <bits/stdc++.h>

using namespace std;

typedef vector<map<int, int>> graph;
typedef map<int, int>::iterator it;

#define INF numeric_limits<int>::max()

bool bfs(graph &g, vector<int> &level, int s, int t) {
	for (int i = 0; i < g.size(); ++i) {
		level[i] = -1;
	}
	level[s] = 0;

	queue<int> q; q.push(s);

	while (!q.empty()) {
		int u = q.front(); q.pop();
		for (auto e : g[u]) {
			int v = e.first, w = e.second;
			if (level[v] < 0 && w > 0) {
				level[v] = level[u] + 1;
				q.push(v);
			}
		}
	}

	return level[t] >= 0;
}

int dfs(graph &g, vector<int> &level, vector<it> &start, int u, int t, int flow) {
	if (u == t) return flow;

	for (it& e = start[u]; e != g[u].end(); ++e) {
		int v = e->first, w = e->second;
		if (level[v] == level[u]+1 && w > 0) {
			int cur_flow = min(flow, w);
			int temp_flow = dfs(g, level, start, v, t, cur_flow);
			if (temp_flow > 0) {
				g[u][v] -= temp_flow;
				g[v][u] += temp_flow;
				return temp_flow;
			}
		}
	}

	return 0;
}

int dinic(graph &g, int s, int t) {
	int total = 0;
	vector<int> level(g.size());
	vector<it> start(g.size());

	while (bfs(g, level, s, t)) {
		for (int i = 0; i < g.size(); ++i) start[i] = g[i].begin();
		while (int flow = dfs(g, level, start, s, t, INF)) {
			total += flow;
		}
	}

	return total;
}

void bfs2(graph &g, vector<bool> &vis, int src, bool forward) {
    queue<int> q; q.push(src);
    while (!q.empty()) {
        int cur = q.front(); q.pop();
        if (vis[cur]) continue;
        vis[cur] = true;
        for (auto &p : g[cur]) {
            if ((p.second > 0) == forward) {
                q.push(p.first);
            }
        }
    }
}

int main() {
    int n, m; cin >> n >> m;
    graph g(2*n+2);
    int src = 2*n, snk = src+1;
    for (int i = 0; i < n; ++i) {
        g[src][i] = 1;
        g[i][src] = 0;
        g[n+i][snk] = 1;
        g[snk][n+i] = 0;
    }
    for (int i = 0; i < m; ++i) {
        int a, b; cin >> a >> b;
        --a; --b;
        g[a][n+b] = 1;
        g[n+b][a] = 0;
    }
    int flights = (n-1) - dinic(g, src, snk);
    cout << flights << endl;
    if (flights > 0) {
        vector<bool> start(g.size()), end(g.size());
        bfs2(g, end, src, true);
        bfs2(g, start, snk, false);
        set<int> air;
        for (int i = 0; i < n; ++i) {
            if (end[i] || start[n+i]) air.insert(i+1);
        }
        for (int i : air) cout << i << " ";
        cout << endl;
    }
}
