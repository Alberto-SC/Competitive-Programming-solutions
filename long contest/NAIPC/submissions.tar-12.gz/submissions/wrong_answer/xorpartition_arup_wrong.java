// Arup Guha
// 2/21/2019
// Incorrect Solution for 2019 Proposed NAIPC Problem: Xor Partition

import java.util.*;

public class xorpartition_arup_wrong {
	
	final public static long MOD = 1000000007L;
	
	public static int numbits;
	public static int n;
	
	public static void main(String[] args) {
		
		// Set up our subsets.
		Scanner stdin = new Scanner(System.in);
		numbits = stdin.nextInt();
		n = stdin.nextInt();
		subset[] sets = new subset[n];
		for (int i=0; i<n; i++) sets[i] = new subset(numbits);

		// Create the partition from the data.
		for (int i=0; i<(1<<numbits); i++) {
			int group = stdin.nextInt()-1;
			sets[group].add(i);
		}
						
		// Output the result.
		System.out.println(go(sets));
	}
	
	// Returns the result.
	public static long go(subset[] sets) {
		
		long res = 1L;
		
		// Just multiply the # of ways to achieve each subset.
		for (subset s: sets)
			res = (res*s.numWays())%MOD;
				
		// This is our answer.
		return res;
	}
}

class subset {
	
	private int numbits;
	private ArrayList<Integer> set;
	
	// Creates an empty subset.
	public subset(int m) {
		set = new ArrayList<Integer>();
		numbits = m;
	}
	
	public void add(int x) {
		set.add(x);
	}
	
	// Returns the bit mask of all bits that are common amongst all pairs of
	// items in this subset.
	private int sameBits() {
		
		int allOnes = (1<<numbits)-1;
		int res = allOnes;
		
		// Go through everything after item 0.
		for (int i=1; i<set.size(); i++) {
			
			// See what 0 and item i share.
			int xor = set.get(0) ^ set.get(i);
			xor ^= allOnes;
			
			// And this into the total result.
			res &= xor;
		}
		
		return res;
	}
	
	// Returns if this is a potential subset of a partition.
	public long numWays() {
		
		// Get bitmask of common sets.
		int matches = sameBits();
		
		// These are the bits that are different.
		int diffBits = numbits - Integer.bitCount(matches);
		
		// The only way an individual partition is valid is iff it contains EVERY item
		// where the same bits are set the same. There are pow(2, diffBits) of these.
		if (set.size() != (1<<diffBits)) return 0;
		
		// This doesn't work because it doesn't take order into account or the other partitions.
		// It turns out that occasionally the partition {0,2,4,6} is valid and other times it's not,
		// for example, but this solution just judges a partition independently of the others and
		// without any concern for the order of the bits, which matters.
		return (1<<diffBits); 
	}
}
