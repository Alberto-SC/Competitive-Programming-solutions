import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Solution to Inflation
 * 
 * @author vanb
 */
public class inflation_vanb
{
    
    /** The Input. */
    private static Scanner sc;
    
    /** The Output. */
    private static PrintStream ps;
    
    /**
     * Is this value known?
     *
     * @param x Value to test
     * @return true, if x is known (not -1), otherwise false.
     */
    private boolean known( double x )
    {
        return x>-0.5;
    }
    
    /**
     * Transitive closure.
     *
     * @param a An array
     * @param i An index
     * @param j Another index
     * @param k A third index
     * @return true, if a[i][k] is previously unknown but can be computed from a[i][j] and a[j][k]
     */
    private boolean transitive( double a[][], int i, int j, int k )
    {
        boolean changed = false;
        if( !known(a[i][k]) && known(a[i][j]) && known(a[j][k]) )
        {
            a[i][k] = a[i][j] * a[j][k];
            a[k][i] = 1.0 / a[i][k];
            changed = true;
        }
        
        return changed;
    }
    
    /**
     * Do It!
     */
    private void doit()
    {
        int y = sc.nextInt();
        int c = sc.nextInt();
        int q = sc.nextInt();
        
        // We get the inflation for year i to year i+1.
        // But, we can find the inflation rate between any two years.
        // So, inflation needs to be a 2D array.
        double inflation[][] = new double[y][y];
        
        // Initialize inflation array
        for( int i=0; i<y; i++ )  Arrays.fill( inflation[i], -1.0 );
        
        // Read in inflation values for year i to year i+1
        for( int i=0; i<y-1; i++ )
        {
            inflation[i][i] = 1.0;
            inflation[i][i+1] = sc.nextDouble();
            inflation[i+1][i] = 1.0 / inflation[i][i+1];
        }        
        inflation[y-1][y-1] = 1.0;
        
        // We don't know any of the modifiers yet, we'll need to compute them.
        double modifiers[] = new double[c];
        Arrays.fill( modifiers, -1.0 );
        
        double ratios[][] = new double[c][c];
        for( int i=0; i<c; i++ )  Arrays.fill( ratios[i], -1.0 );
        
        // Read in the prices
        double prices[][] = new double[y][c];
        for( int i=0; i<y; i++ ) for( int j=0; j<c; j++ ) prices[i][j] = sc.nextDouble();
        
        // We'll keep going until we've filled in as much of 
        // the prices, modifiers and inflation arrays as possible.
        boolean changed;
        do
        {
            changed = false;
            
            // Transitive closure of Inflation
            for( int i=0; i<y; i++) for( int j=i+1; j<y; j++ )for( int k=j+1; k<y; k++ )
            {
                changed |= transitive( inflation, i, j, k );
                changed |= transitive( inflation, i, k, j );
                changed |= transitive( inflation, j, i, k );
                changed |= transitive( inflation, j, k, i );
                changed |= transitive( inflation, k, i, j );
                changed |= transitive( inflation, k, j, i );
            }
            
            // See of we can compute ratios
            for( int x=0; x<c; x++ ) for( int z=x+1; z<c; z++ ) 
            {
                for( int i=0; i<y; i++ ) for( int j=i+1; j<y; j++ )
                {
                    if( known(prices[i][x]) && known(prices[i][z]) && known(prices[j][x]) && known(prices[j][z]) )
                    {
                        if( !known(modifiers[x]) && known(modifiers[z]) )
                        {
                            modifiers[x] = modifiers[z]*Math.pow(prices[j][x]*prices[i][z]/prices[j][z]/prices[i][x], 1.0/(j-i));
                            changed = true;
                        }
                        if( !known(modifiers[z]) && known(modifiers[x]) )
                        {
                            modifiers[z] = modifiers[x]*Math.pow(prices[j][z]*prices[i][x]/prices[j][x]/prices[i][z], 1.0/(j-i));
                            changed = true;
                        }
                    }
                    
                    if( !known(ratios[x][z]) && ratios[x][z]>-1.5 )
                    {
                        if( known(prices[i][x]) && known(prices[j][x]) && known(prices[i][z]) && known(prices[j][z]) )
                        {
                            if( Math.abs(prices[j][x]/prices[j][z] - prices[i][x]/prices[i][z])<0.00000001 )
                            {
                                ratios[x][z] = prices[j][x]/prices[j][z];
                                ratios[z][x] = 1.0/ratios[x][z];
                                changed = true;
                            }
                            else 
                            {
                                ratios[x][z] = ratios[z][x] = -2.0;
                                changed = true;
                            }
                        }
                    }
                }
            }
            
            // See of we can use ratios
            for( int k1=0; k1<c; k1++ ) for( int k2=k1+1; k2<c; k2++ ) if( known(ratios[k1][k2]) )
            {
                for( int i=0; i<y; i++ ) 
                {
                    if( !known(prices[i][k1]) && known(prices[i][k2]) ) prices[i][k1] = prices[i][k2]*ratios[k1][k2];
                    if( !known(prices[i][k2]) && known(prices[i][k1]) ) prices[i][k2] = prices[i][k1]*ratios[k2][k1];
                }
            }
            
            // Compute Modifiers, Prices, Inflation if we can
            for( int i=0; i<y; i++ ) for( int j=i+1; j<y; j++ ) for( int k=0; k<c; k++ )
            {
                // OK, prices[i][k] = prices[j][k] * inflation[j][i] / (modifiers[k]^(j-i));
                // and prices[j][k] = prices[i][k] * inflation[i][j] * (modifiers[k]^(j-i));
                // If we know any 3, we can compute the 4th.
                if( !known(modifiers[k]) && known(prices[i][k]) && known(prices[j][k]) && known(inflation[i][j]) )
                {
                    modifiers[k] = Math.pow( prices[j][k] / prices[i][k] / inflation[i][j], 1.0 / (j-i) );
                    changed = true;
                }
                
                if( !known(prices[i][k]) && known(modifiers[k]) && known(prices[j][k]) && known(inflation[j][i]))
                {
                    prices[i][k] = prices[j][k] * inflation[j][i] / Math.pow( modifiers[k], j-i );
                    changed = true;
                }
                
                if( !known(prices[j][k]) && known(modifiers[k]) && known(prices[i][k]) && known(inflation[i][j]))
                {
                    prices[j][k] = prices[i][k] * inflation[i][j] * Math.pow( modifiers[k], j-i );
                    changed = true;
                }
                
                if( !known(inflation[i][j]) && known(modifiers[k]) && known(prices[i][k]) && known(prices[j][k]) )
                {
                    inflation[i][j] = prices[j][k] / prices[i][k] / Math.pow( modifiers[k], j-i );
                    inflation[j][i] = 1.0 / inflation[i][j];
                    changed = true;
                }
            }
        } while( changed );
        
        // OK, now answer the queries by just looking in the prices[][] table.
        for( int i=0; i<q; i++ )
        {
            int a = sc.nextInt()-1;
            int b = sc.nextInt()-1;
            ps.printf( "%.2f", prices[b][a] );
            ps.println();
        }
    }
        
    /**
     * Main!
     * 
     * @param args unused
     * @throws Exception
     */
    public static void main( String[] args ) throws Exception
    {
        sc = new Scanner( System.in );
        ps = System.out;
        
        new inflation_vanb().doit();
    }

}
