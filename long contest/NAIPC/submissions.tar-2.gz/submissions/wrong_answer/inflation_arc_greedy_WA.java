import java.io.PrintWriter;
import java.util.*;

/*

Should break on a case like this:
10 4 1
-1 -1 -1 -1 -1 1 1 1 -1
-1 -1 -1 -1
 2  2 -1  2
-1 -1 -1 -1
 2  2 -1 -1
-1 -1 -1 -1
 2 -1 -1 -1
-1  2 -1 -1
-1 -1 -1 -1
-1 -1 -1  2
-1 -1 -1 -1
4 4



 */
public class inflation_arc_greedy_WA {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);
		int y = in.nextInt();
		int c = in.nextInt();
		int q = in.nextInt();

		double[] inflation = new double[y - 1];
		for (int i = 0; i < y - 1; i++)
			inflation[i] = in.nextDouble();

		double prices[][] = new double[y][c];
		for (int i = 0; i < y; i++)
			for (int j = 0; j < c; j++)
				prices[i][j] = in.nextDouble();

		for (int k = 0; k < c; k++) {
			double modifier = -1;
			for (int i = 0, j; i < y && !known(modifier); i = j) {
				j = i + 1;
				if (!known(prices[i][k]))
					continue;
				double rate = 1;
				while (j < y && known(inflation[j - 1])) {
					rate *= inflation[j - 1];
					if (known(prices[i][k]) && known(prices[j][k])) {
						modifier = Math.pow(prices[j][k] / prices[i][k] / rate, 1.0 / (j - i));
						break;
					}
					j++;
				}
			}
			if (known(modifier))
				for (int i = 0, j; i < y; i = j) {
					double rate = 1;
					for (j = i + 1; j < y && known(inflation[j - 1]) && !known(prices[i][k]); j++) {
						rate *= inflation[j - 1];
						if (known(prices[j][k])) {
							prices[i][k] = prices[j][k] / rate / Math.pow(modifier, j - i);
						}
					}

					rate = 1;
					if (known(prices[i][k]))
						for (j = i + 1; j < y && known(inflation[j - 1]); j++) {
							rate *= inflation[j - 1];
							if (!known(prices[j][k]) && known(prices[i][k])) {
								prices[j][k] = prices[i][k] * rate * Math.pow(modifier, j - i);
							}
						}
				}
		}
		for (int i = 0; i < c; i++) {
			for (int j = 0; j < c; j++) {
				if(i == j)
					continue;
				ArrayList<Integer> sharedYears = new ArrayList<>();
				for (int k = 0; k < y; k++)
					if (known(prices[k][i]) && known(prices[k][j]))
						sharedYears.add(k);
				if (sharedYears.size() >= 2) {
					int a = sharedYears.get(0), b = sharedYears.get(1);
					double r1 = prices[b][j] / prices[a][j];
					double r2 = prices[b][i] / prices[a][i];
					double rat = Math.pow(r1 / r2, 1.0 / (b - a));
					for (int k = 0; k < y; k++) {
						if (known(prices[k][i]) && !known(prices[k][j])) {
							double rate = prices[k][i] / prices[b][i] * Math.pow(rat, k - b);
							prices[k][j] = prices[b][j] * rate;
						} else if (!known(prices[k][i]) && known(prices[k][j])) {
							double rate = prices[k][j] / prices[b][j] * Math.pow(1 / rat, k - b);
							prices[k][i] = prices[b][i] * rate;
						}
					}
				}
			}
		}

		for (int i = 0; i < q; i++) {
			int a = in.nextInt() - 1;
			int b = in.nextInt() - 1;
			out.println(prices[b][a]);
		}
		out.close();
	}
	static boolean known(double x) {
		return x > -0.5;
	}

}