import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Solution to Inflation
 * 
 * @author vanb & arcoleman
 */
public class inflation_vanb_arc_WA2
{
    
    /** The Input. */
    private static Scanner sc;
    
    /** The Output. */
    private static PrintStream ps;
    
    /**
     * Is this value known?
     *
     * @param x Value to test
     * @return true, if x is known (not -1), otherwise false.
     */
    private boolean known( double x )
    {
        return x>-0.5;
    }
    
    /**
     * Transitive closure.
     *
     * @param a An array
     * @param i An index
     * @param j Another index
     * @param k A third index
     * @return true, if a[i][k] is previously unknown but can be computed from a[i][j] and a[j][k]
     */
    private boolean transitive( double a[][], int i, int j, int k )
    {
        boolean changed = false;
        if( !known(a[i][k]) && known(a[i][j]) && known(a[j][k]) )
        {
            a[i][k] = a[i][j] * a[j][k];
            a[k][i] = 1.0 / a[i][k];
            changed = true;
        }
        
        return changed;
    }
    
    /**
     * Do It!
     */
    private void doit()
    {
        int y = sc.nextInt();
        int c = sc.nextInt();
        int q = sc.nextInt();
        
        // We get the inflation for year i to year i+1.
        // But, we can find the inflation rate between any two years.
        // So, inflation needs to be a 2D array.
        double inflation[][] = new double[y][y];
        
        // Initialize inflation array
        for( int i=0; i<y; i++ )  Arrays.fill( inflation[i], -1.0 );
        
        // Read in inflation values for year i to year i+1
        for( int i=0; i<y-1; i++ )
        {
            inflation[i][i] = 1.0;
            inflation[i][i+1] = sc.nextDouble();
            inflation[i+1][i] = 1.0 / inflation[i][i+1];
        }        
        inflation[y-1][y-1] = 1.0;
        
        // We don't know any of the modifiers yet, we'll need to compute them.
        double modifiers[] = new double[c];
        Arrays.fill( modifiers, -1.0 );
        
        // Read in the prices
        double prices[][] = new double[y][c];
        for( int i=0; i<y; i++ ) for( int j=0; j<c; j++ ) prices[i][j] = sc.nextDouble();
        
        // We'll keep going until we've filled in as much of 
        // the prices, modifiers and inflation arrays as possible.
        boolean changed;
        do
        {
            changed = false;
            
            // Transitive closure of Inflation
            /*for( int i=0; i<y; i++) for( int j=i+1; j<y; j++ )for( int k=j+1; k<y; k++ )
            {
                changed |= transitive( inflation, i, j, k );
                changed |= transitive( inflation, i, k, j );
                changed |= transitive( inflation, j, i, k );
                changed |= transitive( inflation, j, k, i );
                changed |= transitive( inflation, k, i, j );
                changed |= transitive( inflation, k, j, i );
            }*/
            
            // Compute Modifiers, Prices, Inflation if we can
            for( int i=0; i<y; i++ ) for( int j=i+1; j<y; j++ ) for( int k=0; k<c; k++ )
            {
                // OK, prices[i][k] = prices[j][k] * inflation[j][i] / (modifiers[k]^(j-i));
                // and prices[j][k] = prices[i][k] * inflation[i][j] * (modifiers[k]^(j-i));
                // If we know any 3, we can compute the 4th.
                if( !known(modifiers[k]) && known(prices[i][k]) && known(prices[j][k]) && known(inflation[i][j]) )
                {
                    modifiers[k] = Math.pow( prices[j][k] / prices[i][k] / inflation[i][j], 1.0 / (j-i) );
                    changed = true;
                }
                
                /*if( !known(prices[i][k]) && known(modifiers[k]) && known(prices[j][k]) && known(inflation[j][i]))
                {
                    prices[i][k] = prices[j][k] * inflation[j][i] / Math.pow( modifiers[k], j-i );
                    changed = true;
                }*/
                
                if( !known(prices[j][k]) && known(modifiers[k]) && known(prices[i][k]) && known(inflation[i][j]))
                {
                    prices[j][k] = prices[i][k] * inflation[i][j] * Math.pow( modifiers[k], j-i );
                    changed = true;
                }
                
                if( !known(inflation[i][j]) && known(modifiers[k]) && known(prices[i][k]) && known(prices[j][k]) )
                {
                    inflation[i][j] = prices[j][k] / prices[i][k] / Math.pow( modifiers[k], j-i );
                    inflation[j][i] = 1.0 / inflation[i][j];
                    changed = true;
                }
            }
            
            // Handle case without any inflation rates
            for(int i=0;i<c;i++) {
            	for(int j=i+1;j<c;j++) {
            		int a = -1;
            		int b = -1;
            		for(int k=0;k<y;k++) {
            			if(prices[k][i] > -.5 && prices[k][j] > -.5) {
            				if(a == -1)
            					a = k;
            				else
            					b = k;
            			}
            		}
            		// If two commodities share a year, then we can convert either of them to each other
            		if(a != -1 && b != -1) {
    					double r1 = prices[b][j] / prices[a][j];
    					double r2 = prices[b][i] / prices[a][i];
    					double rat = Math.pow(r1/r2, 1.0/(b-a));
	            		for(int k=0;k<y;k++) {
	            			if(prices[k][i] > -.5 && prices[k][j] < -.5) {
	            				double rate = prices[k][i] / prices[b][i] * Math.pow(rat, k-b);
	            				prices[k][j] = prices[b][j] * rate;
	            				changed = true;
	            			} else if(prices[k][i] < -.5 && prices[k][j] > -.5) {
	            				double rate = prices[k][j] / prices[b][j] * Math.pow(1/rat, k-b);
	            				prices[k][i] = prices[b][i] * rate;
	            				changed = true;
	            			}
	            		}
            		}
            	}
            }
        } while( changed );
        
        // OK, now answer the queries by just looking in the prices[][] table.
        for( int i=0; i<q; i++ )
        {
            int a = sc.nextInt()-1;
            int b = sc.nextInt()-1;
            ps.println( prices[b][a] );
        }
    }
        
    /**
     * Main!
     * 
     * @param args unused
     * @throws Exception
     */
    public static void main( String[] args ) throws Exception
    {
        sc = new Scanner( System.in );
        ps = System.out;
        
        new inflation_vanb_arc_WA2().doit();
    }

}