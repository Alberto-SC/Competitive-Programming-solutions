import java.util.*;

/*
 * Problem: Inflation (NAIPC19)
 * Author: Alex Coleman
 * Complexity: O(y^3*c + c^3*y + q*(y^2+c^2))
 * 
 * All operations in the problem are multiplication; by taking the log of
 * all values, the operations become addition. Then, we simply have a system
 * of linear equations, and a set of query linear expressions.
 * This can be solved by applying gaussian elimination to the input equations, then
 * 'eliminating' the query expressions.
 */
public class Inflation_arc {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int y = in.nextInt();
		int c = in.nextInt();
		int q = in.nextInt();
		double[] inflations = new double[y-1];
		for(int i=0;i<y-1;i++)
			inflations[i] = in.nextDouble();
		double[][] grid = new double[y][c];
		for(int i=0;i<y;i++) {
			for(int j=0;j<c;j++) {
				grid[i][j] = in.nextDouble();
			}
		}
		
		int varId = 0;
		int[] inflIds = new int[y-1];
		int[] modIds = new int[c];
		int[] p0Ids = new int[c];
		for(int i=0;i<y-1;i++)
			inflIds[i] = varId++;
		for(int i=0;i<c;i++)
			modIds[i] = varId++;
		for(int i=0;i<c;i++)
			p0Ids[i] = varId++;
		
		double[][] mat = new double[y*c+y-1][varId+1];
		int eqnId = 0;
		for(int i=0;i<y-1;i++) {
			if(inflations[i] < -.5)
				continue;
			mat[eqnId][inflIds[i]] = 1;
			mat[eqnId][varId] = Math.log(inflations[i]);
			eqnId++;
		}
		for(int i=0;i<y;i++) {
			for(int j=0;j<c;j++) {
				if(grid[i][j] < -.5)
					continue;
				mat[eqnId][modIds[j]] = i;
				mat[eqnId][p0Ids[j]] = 1;
				for(int k=0;k<i;k++)
					mat[eqnId][inflIds[k]] = 1;
				mat[eqnId][varId] = Math.log(grid[i][j]);
				eqnId++;
			}
		}
		gaussian(mat);
		for(int qi=0;qi<q;qi++) {
			int comm = in.nextInt()-1;
			int year = in.nextInt()-1;
			double[] query = new double[varId+1];
			query[p0Ids[comm]] = 1;
			query[modIds[comm]] = year;
			for(int i=0;i<year;i++)
				query[inflIds[i]] = 1;
			for(int pr=0;pr<eqnId;pr++) {
				int pc = -1;
				for(int j=0;j<=varId;j++) {
					if(!eq(mat[pr][j], 0)) {
						pc = j;
						break;
					}
				}
				if(pc == -1)
					break;
				double ratio = -query[pc];
				for (int k = pc; k <= varId; k++)
					query[k] += mat[pr][k] * ratio;
			}
			boolean isUnique = true;
			for(int i=0;i<varId;i++) {
				if(!eq(query[i], 0)) {
					isUnique = false;
					break;
				}
			}
			System.out.println(isUnique ? Math.exp(-query[varId]) : -1);
		}
		
	}
	static void swap(double[][] m, int a, int b) {
		double[] ra = m[a];
		m[a] = m[b];
		m[b] = ra;
	}
	static boolean eq(double x, double y) {
		return Math.abs(x-y) < 1e-8;
	}
	public static void gaussian(double[][] m) {
		int R = m.length, C = m[0].length;
		int pc = 0, pr = 0;
		while (pr < R && pc < C) {
			int sr = pr;
			for (int j = pr + 1; j < R; j++)
				if (Math.abs(m[j][pc]) > Math.abs(m[sr][pc]))
					sr = j;
			swap(m, sr, pr);
			if (eq(m[pr][pc],0)) {
				pc++;
				continue;
			}
			if(pc == C-1) {
				System.err.println("Data is inconsistent");
				System.exit(1);
			}
			double piv = m[pr][pc];
			for (int j = pc; j < C; j++)
				m[pr][j] /= piv;
			for (int j = 0; j < R; j++) {
				if(j == pr) continue;
				double ratio = -m[j][pc];
				for (int k = pc; k < C; k++) {
					m[j][k] += m[pr][k] * ratio;
				}
			}
			pc++;
			pr++;
		}
	}
}
