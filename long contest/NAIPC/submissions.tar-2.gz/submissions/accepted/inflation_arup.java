// Arup Guha
// 2/21/2019
// Solution? to 2019 NAIPC Proposed Problem: Inflation
// I run my queries one by one, instead of all at once, not sure if we want
// this to be TLE or AC. For the cases now, this takes 1.01 in the worst case
// on my desktop. For now, I'll put it in the AC folder, but it can be moved
// to TLE if we determine that we want students to run all the queries at once,
// (which, I think should be faster.)

import java.util.*;

public class inflation_arup {
	
	final public static double EPS = 1e-9;
	
	public static int numYears;
	public static int numItems;
	
	public static double[] inflation;
	public static double[][] prices;
	public static ArrayList<double[]> eqns;
	
	public static boolean[] noPriceList;
	
	public static void main(String[] args) {
		
		Scanner stdin = new Scanner(System.in);
		numYears = stdin.nextInt();
		numItems = stdin.nextInt();
		int numQ = stdin.nextInt();
		
		// Read inflation.
		inflation = new double[numYears-1];
		for (int i=0; i<numYears-1; i++)
			inflation[i] = stdin.nextDouble();
		
		// Read prices.
		prices = new double[numYears][numItems];
		for (int i=0; i<numYears; i++)
			for (int j=0; j<numItems; j++)
				prices[i][j] = stdin.nextDouble();
	
		noPriceList = new boolean[numItems];
		
		// 0 to nI-1 are modifiers, nI to nI+nY-2 are inflations.
		eqns = new ArrayList<double[]>();
		for (int j=0; j<numItems; j++) {
			
			// Get valid list of years.
			ArrayList<Integer> validIdx = new ArrayList<Integer>();
			for (int i=0; i<numYears; i++) {
				if (prices[i][j] > -.5)
					validIdx.add(i);
			}
			
			// We need two prices for a single commodity to nail anything down,
			// except given information.
			noPriceList[j] = (validIdx.size() < 2);
			
			// Make equations here.
			for (int i=0; i<validIdx.size()-1; i++) {
				
				// Two valid years.
				int y1 = validIdx.get(i);
				int y2 = validIdx.get(i+1);
				int diff = y2 - y1;
				
				// Equation is stored here.
				double[] tmp = new double[numItems+numYears];
				
				// Eqn RHS from given info of the two years.
				tmp[tmp.length-1] = ( Math.log(prices[y2][j]) - Math.log(prices[y1][j]) );
				
				// This is the coefficient for log modifier(A), in equation building
				// price from year y1 to year y2.
				tmp[j] = diff;
				
				// Coefficients for the sum of each year's log inflation variable.
				for (int k=y1; k<y2; k++) {
					if (inflation[k] > 0) 	tmp[tmp.length-1] -= Math.log(inflation[k]); 
					else 					tmp[numItems+k] = 1;
				}
				
				// Here is our equation.
				eqns.add(tmp);
			}
		}
		
		// Initial version - we will solve each query 1 by 1.
		for (int i=0; i<numQ; i++) {
			
			// Get query.
			int item = stdin.nextInt() - 1;
			int year = stdin.nextInt() - 1;
			
			// They gave it directly =)
			if (prices[year][item] > -.5)
				System.out.printf("%.10f\n",prices[year][item]);
			
			// If they didn't give it to us and we have 0 or 1 data point, we can't do it.
			else if (noPriceList[item])
				System.out.println("-1.0");
			
			// Give it a shot the long way.
			else {
				double res = solve(year, item);
				if (res < 0)	System.out.println("-1.0");
				else			System.out.printf("%.10f\n", res);
			}
		}
	}
	
	public static double solve(int year, int item) {
		
		double[] lasteqn = new double[numItems+numYears];
		
		// Get anchor first - guaranteed we have two prices if we get here.
		int knownYear = 0;
		while (prices[knownYear][item] < 0) knownYear++;
		
		// Which way are we looping.
		int sign = knownYear < year ? 1 : -1;
		int startI = Math.min(knownYear, year);
		int endI = Math.max(knownYear, year);
		
		// This is the last equation, "setting unknown price to 0"
		lasteqn[lasteqn.length-1] = -Math.log(prices[knownYear][item]);
		lasteqn[item] = year-knownYear;
		
		// Sets each inflation variable (or subs it out if known)
		for (int k=startI; k<endI; k++) {
			if (inflation[k] > 0) 	lasteqn[lasteqn.length-1] -= sign*Math.log(inflation[k]);
			else 					lasteqn[numItems+k] = sign;
		}
		
		// All eqns stored here.
		ArrayList<double[]> myeqns = makeCopy(eqns);
		myeqns.add(lasteqn);
		
		// Solve this "augmented" system.
		return gaussian(myeqns);
	}
	
	// Returns a copy of all of our equations.
	public static ArrayList<double[]> makeCopy(ArrayList<double[]> orig) {
		ArrayList<double[]> res = new ArrayList<double[]>();
		for (int i=0; i<orig.size(); i++) {
			double[] tmp = new double[orig.get(i).length];
			for (int j=0; j<tmp.length; j++)
				tmp[j] = orig.get(i)[j];
			res.add(tmp);
		}
		return res;
	}
	
	public static double gaussian(ArrayList<double[]> myeqns) {

		// Basic eqn info.
		int n = myeqns.size();
		int numvars = numItems+numYears-1;		
		int curNonZeroMin = getNonZeroCol(myeqns, 0);

		// i is equation we use for elimination.
		for (int i=0; i<n-1; i++) {
			
			int bestEqn = -1;
			double bestCoeff = 0;
			
			// Find best item in column curNonZeroMin.
			for (int j=i; j<n-1; j++) {
				
				double coeff = Math.abs(myeqns.get(j)[curNonZeroMin]);
				if (coeff < EPS) continue;
				
				if (bestEqn == -1 || coeff > bestCoeff) {
					bestCoeff = coeff;
					bestEqn = j;
				}
			}
			
			// Get out! No pivot equation.
			if (bestEqn == -1) break;
			
			// Swap references here.
			double[] tmp = myeqns.get(i);
			myeqns.set(i, myeqns.get(bestEqn));
			myeqns.set(bestEqn, tmp);
			
			// Zero out this column.
			for (int j=i+1; j<myeqns.size(); j++) {
				double factor = myeqns.get(j)[curNonZeroMin]/myeqns.get(i)[curNonZeroMin];

				// Sub out.
				for (int z=curNonZeroMin; z<=numvars; z++)
					myeqns.get(j)[z] -= factor*myeqns.get(i)[z];
			}			
			
			// This means we solved it.
			if (zero(myeqns.get(myeqns.size()-1)))
				return Math.exp(-myeqns.get(myeqns.size()-1)[numvars]);
			
			// Update for next iteration.
			curNonZeroMin = getNonZeroCol(myeqns, i+1);
		}
		
		// Check again before giving up.
		if (zero(myeqns.get(myeqns.size()-1)))
			return Math.exp(-myeqns.get(myeqns.size()-1)[numvars-1]);		
		
		// Couldn't do it.
		return -1;
	}
	
	// Returns the minimum non-zero column in equations myeqns[startRow...size-1].
	public static int getNonZeroCol(ArrayList<double[]> myeqns, int startRow) {
		int numvars = myeqns.get(0).length;
		int curNonZeroMin = numvars;
		for (int i=startRow; i<myeqns.size(); i++) {
			int ans = 0;
			while (ans < numvars && Math.abs(myeqns.get(i)[ans]) < EPS) ans++;
			curNonZeroMin = Math.min(curNonZeroMin, ans);
		}		
		return curNonZeroMin;
	}
	
	// Returns true iff all coefficients (all except last entry) are 0.
	public static boolean zero(double[] eqn) {
		for (int i=0; i<eqn.length-1; i++)
			if (Math.abs(eqn[i]) > EPS)
				return false;
		return true;
	}
}
