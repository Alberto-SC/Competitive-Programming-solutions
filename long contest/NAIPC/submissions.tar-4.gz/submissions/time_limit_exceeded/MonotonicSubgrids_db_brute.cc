// Problem         : Hammering (NAIPC 2019)
// Author          : Darcy Best
// Expected Result : TLE
// Complexity      : O( 2^n * 2^m * m * n )

// Just try all subsets

#include <iostream>
#include <vector>
using namespace std;

int n, m;

int tmp[100];

bool good(const vector<vector<int> >& A, int R_bM,int C_bM){
  for(int r=0;r<n;r++){
    if(((R_bM >> r) & 1) == 0) continue;
    int idx = 0;
    for(int c=0;c<m;c++)
      if((C_bM >> c) & 1)
        tmp[idx++] = A[r][c];
    for(int i=0;i+2<idx;i++)
      if(!(tmp[i] < tmp[i+1] && tmp[i+1] < tmp[i+2]) &&
         !(tmp[i] > tmp[i+1] && tmp[i+1] > tmp[i+2]))
        return false;
  }

  for(int c=0;c<m;c++){
    if(((C_bM >> c) & 1) == 0) continue;
    int idx = 0;
    for(int r=0;r<n;r++)
      if((R_bM >> r) & 1)
        tmp[idx++] = A[r][c];
    for(int i=0;i+2<idx;i++)
      if(!(tmp[i] < tmp[i+1] && tmp[i+1] < tmp[i+2]) &&
         !(tmp[i] > tmp[i+1] && tmp[i+1] > tmp[i+2]))
        return false;
  }

  return true;
}

int main(){
  cin >> n >> m;

  vector<vector<int> > A(n, vector<int>(m));
  for(auto& v : A)
    for(auto& x : v)
      cin >> x;

  long long ans = 0;
  for(int rows_bM=1;rows_bM<(1 << n);rows_bM++)
    for(int cols_bM=1;cols_bM<(1 << m);cols_bM++)
      if(good(A,rows_bM,cols_bM))
        ans++;

  cout << ans << endl;
}
