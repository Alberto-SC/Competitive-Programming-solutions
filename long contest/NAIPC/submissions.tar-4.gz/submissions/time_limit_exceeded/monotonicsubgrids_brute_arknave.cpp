#include <cstdio>
#include <vector>

using namespace std;
using vi = vector<int>;

/**
 * O(2^n 2^m n m) brute force using some short-circuiting
 */
constexpr int MAXN = 20;
int n, m;
int a[MAXN][MAXN];
int buf[MAXN];

inline bool is_monotonic(int len) {
    if (len <= 2)
        return true;

    bool inc = buf[1] > buf[0];
    for (int i = 2; i < len; ++i) {
        if (inc != buf[i] > buf[i - 1]) {
            return false;
        }
    }

    return true;
}

int main() {
    scanf(" %d %d", &n, &m);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            scanf(" %d", &a[i][j]);
        }
    }

    int ans = 0;
    for (int row_mask = 1; row_mask < (1 << n); ++row_mask) {
        for (int col_mask = 1; col_mask < (1 << m); ++col_mask) {
            // check each row is monotonic
            bool valid = true;
            for (int i = 0; valid and i < n; ++i) {
                if ((row_mask & (1 << i)) == 0) {
                    continue;
                }

                int p = 0;
                for (int j = 0; j < m; ++j) {
                    if (col_mask & (1 << j)) {
                        buf[p++] = a[i][j];
                    }
                }

                valid &= is_monotonic(p);
            }

            // now check each column is monotonic
            for (int j = 0; valid and j < m; ++j) {
                if ((col_mask & (1 << j)) == 0) {
                    continue;
                }

                int p = 0;
                for (int i = 0; i < n; ++i) {
                    if (row_mask & (1 << i)) {
                        buf[p++] = a[i][j];
                    }
                }

                valid &= is_monotonic(p);
            }
            ans += valid;
        }
    }

    printf("%d\n", ans);
    return 0;
}
