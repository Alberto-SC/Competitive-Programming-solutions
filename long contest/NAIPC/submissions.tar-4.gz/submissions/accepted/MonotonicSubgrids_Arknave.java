import java.io.*;
import java.util.*;

public class MonotonicSubgrids_Arknave {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        int n = Integer.parseInt(st.nextToken());
        int m = Integer.parseInt(st.nextToken());
        int[][] a = new int[n][m];
        for (int i = 0; i < n; i++) {
            st = new StringTokenizer(br.readLine());
            for (int j = 0; j < m; j++) {
                a[i][j] = Integer.parseInt(st.nextToken());
            }
        }

        int[][] incMask = new int[m][m];
        for (int j = 0; j < m; j++) {
            for (int k = 0; k < m; k++) {
                for (int i = 0; i < n; i++) {
                    if (a[i][j] < a[i][k]) {
                        incMask[j][k] |= (1 << i);
                    }
                }
            }
        }

        long ans = 0;
        boolean[] goodCol = new boolean[m];
        int[][] source = new int[1 << n][m];
        int[][] dp = new int[1 << n][m];
        for (int rowMask = 1; rowMask < (1 << n); rowMask++) {
            for (int j = 0; j < m; ++j) {
                int x = -1;
                int y = -1;
                goodCol[j] = true;
                for (int i = 0; goodCol[j] && i < n; i++) {
                    if ((rowMask & (1 << i)) == 0) {
                        continue;
                    }

                    if (x == -1) {
                        x = a[i][j];
                    } else if (y == -1) {
                        y = a[i][j];
                    } else {
                        goodCol[j] &= (x > y) == (y > a[i][j]);
                        y = a[i][j];
                    }
                }

                if (goodCol[j])
                    ++ans;
            }

            for (int j = 0; j < m; j++) {
                if (!goodCol[j]) continue;
                for (int k = j + 1; k < m; k++) {
                    if (!goodCol[k]) continue;
                    int cur = rowMask & incMask[j][k];
                    if (source[cur][j] != rowMask) {
                        source[cur][j] = rowMask;
                        dp[cur][j] = 0;
                    }
                    if (source[cur][k] != rowMask) {
                        source[cur][k] = rowMask;
                        dp[cur][k] = 0;
                    }
                    dp[cur][k] += dp[cur][j] + 1;
                    ans += dp[cur][j] + 1;
                }
            }
        }

        System.out.println(ans);
    }
}
